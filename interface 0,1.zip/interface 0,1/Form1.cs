﻿using Serv;
using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;


namespace @interface
{
    public partial class Form1 : Form
    {
        int num = 0;
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            try
            {
                using (var dbService = new DatabaseService())  // Теперь должно работать
                {
                    string question = dbService.LoadQuestion();

                    if (!string.IsNullOrEmpty(question))
                    {
                        LabelQuest.Text = question;
                    }
                    else
                    {
                        MessageBox.Show("Вопрос не найден в базе данных");
                    }
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show($"Ошибка: {ex.Message}");
            }
        }
    


        private void Button2_Click(object sender, EventArgs e)
        {
            num++;

            if (num >= 3)
            {
                Button2.Visible = false;
                TextAnswer.Visible = false;
                LabelQuest.Visible = false;
                LabelResult.Visible = true;
            }
        }
    






private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }
        private void textBox2_TextChanged(object sender, EventArgs e)

        {

        }
        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }
        private void label1_Click(object sender, EventArgs e)
        {

        }
        private void label2_Click(object sender, EventArgs e)
        {

        }
        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }
    }
}
