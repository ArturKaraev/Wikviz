﻿
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Data.SqlClient;
using System.IO;
using System.Linq;
using System.Net;
using System.Net.Sockets;
using System.Runtime.CompilerServices;
using System.Text;
using System.Threading;
using System.Threading.Tasks;

//Сервер
namespace Serv
{
    internal class Program
    {
        SqlConnection connection = null;
        private TcpListener listener;
        private List<TcpClient> connectedClients = new List<TcpClient>();

        public Program()
        {
            connection = new SqlConnection(@"Data Source=(localdb)\MSSQLLocalDB; Initial Catalog=QUESTIONS; Integrated Security=SSPI;");
        }

        // Этот метот заносит данные в Базу Данных
        public void InsertQuery()
        {
            try
            {
                connection.Open();

                string insert = "" +
                      "INSERT INTO Questions (Id, Quest, Answer) VALUES (1, N'Что выведет этот код?\n\tint i = 0;\n\tConsole.WriteLine(i++ + ++i);', '2');" +
                    "\bINSERT INTO Questions (Id, Quest, Answer) VALUES (2, N'Что произойдет при выполнении этого кода?\n\tstring s = null;\n\tConsole.WriteLine(s is string)', 'False');" +
                    "\bINSERT INTO Questions (Id, Quest, Answer) VALUES (3, N'Что выведет этот код?\n\tConsole.WriteLine(1 / 2 * 3.0);', '0.0');" +
                    "\bINSERT INTO Questions (Id, Quest, Answer) VALUES (4, N'Что выведет этот код?\n\tConsole.WriteLine(1 + 2 + \"3\" + 4 + 5)', '\"3345\"');" +
                    "\bINSERT INTO Questions (Id, Quest, Answer) VALUES (5, N'Что выведет этот код?\n\tvar a = new Action(() => Console.Write(\"A\"));\n\tvar b = new Action(() => Console.Write(\"B\"));\n\tvar c = a + b + a;c();', 'ABA');" +
                    "\bINSERT INTO Questions (Id, Quest, Answer) VALUES (6, N'Что выведет этот код?\n\tvar dict = new Dictionary<string, int> { { \"a\", 1 } };\n\tdict[\"a\"]++;\n\tConsole.WriteLine(dict[\"a\"]);', '2');" +
                    "\bINSERT INTO Questions (Id, Quest, Answer) VALUES (7, N'Какой результат выполнения?\n\ttry {throw new Exception(\"1\");}\n\tcatch (Exception ex)\n\t{Console.Write(ex.Message);\n\tthrow new Exception(\"2\");}\n\tfinally {Console.Write(\"3\");}', N'Программа упадёт с Exception(\"2\")');" +
                    "\bINSERT INTO Questions (Id, Quest, Answer) VALUES (8, N'Что будет, если в switch передать null для enum? enum Color {Red, Green}\n\tColor? color = null;\n\tswitch (color)\n\t{ ... }', N'Ничего, switch обрабатывает null.');" +
                    "\bINSERT INTO Questions (Id, Quest, Answer) VALUES (9, N'Где хранятся локальные переменные метода (не static, не поля класса)?', N'В стеке (stack)');" +
                    "\bINSERT INTO Questions (Id, Quest, Answer) VALUES (10, N'Можно ли создать экземпляр интерфейса в C#?', N'Нет, интерфейсы — это абстракции');" +
                    "\bINSERT INTO Questions (Id, Quest, Answer) VALUES (11, N'Что произойдёт, если в finally бросить исключение?\n\ttry {throw new Exception(\"A\");}\n\tfinally {throw new Exception(\"B\");}', N'Будет выброшено исключение \"B\" (первое теряется)');" +
                    "\bINSERT INTO Questions (Id, Quest, Answer) VALUES (12, N'Может ли деструктор (финализатор) быть вызван явно?\n\tclass Test {~Test() => Console.Write(\"Finalized\");}\n\tvar t = new Test(); // Можно ли вызвать деструктор вручную?', N'Нет, только сборщик мусора вызывает финализатор');";
                string[] inserts = insert.Split('\b');

                foreach (string command in inserts)
                {
                    SqlCommand cmd = new SqlCommand(command, connection);
                    cmd.ExecuteNonQuery();
                }
                Console.WriteLine("This came wonderful");
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Database error: {ex.Message}");
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }

            }
        }

        // Этот метод выводит данные из таблицы, для проверки работы
        // Зачем
        public void PrintQuestions()
        {
            try
            {
                connection.Open();

                string query = $"SELECT Quest FROM QUESTIONS";
                using (var command = new SqlCommand(query, connection))
                using (var reader = command.ExecuteReader())
                {
                    while (reader.Read())
                    {
                        Console.WriteLine($"Question: {reader[0]}");
                    }
                }

            }
            catch (Exception ex)
            {
                Console.WriteLine($"Database error: {ex.Message}");
            }
            finally
            {
                if (connection.State == System.Data.ConnectionState.Open)
                {
                    connection.Close();
                }

            }
        }

        public async Task StartServerAsync(IPAddress ipAddress, int port)
        {
            listener = new TcpListener(ipAddress, port);
            listener.Start();
            Console.WriteLine($"Сервер готов слушать порт {port}");

            try
            {
                while (true)
                {
                    var client = await listener.AcceptTcpClientAsync();
                    _ = HandleClientAsync(client); // Запускаем обработку клиента без ожидания
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Server error: {ex.Message}");
            }
            finally
            {
                listener.Stop();
            }
        }

        private async Task HandleClientAsync(TcpClient client)
        {
            try
            {
                lock (connectedClients)
                {
                    connectedClients.Add(client);
                }

                Console.WriteLine($"Client connected: {client.Client.RemoteEndPoint}");

                using (var stream = client.GetStream())
                {
                    int count = 0;
                    var buffer = new byte[1024];

                    while (client.Connected)
                    {
                        //connection.Open();
                        // До строки 157 выводят информацию о столбцац таблицы, вопрос и ответ
                        // чисто для проверки пока, надо как нибудь клиенту это отправлять
                        
                        string query = $"SELECT Quest, Answer FROM Questions";
                        using (var command = new SqlCommand(query, connection))
                        using (var reader = command.ExecuteReader())
                        {
                            while (reader.Read())
                            {
                                Console.WriteLine($"Question: {reader[0]}  {reader[1]}");
                            }
                        }
                        

                        // Читает ответ клиента
                        var bytesRead = await stream.ReadAsync(buffer, 0, buffer.Length);
                        if (bytesRead == 0) break;

                        // Это че такое
                        var receivedMessage = Encoding.UTF8.GetString(buffer, 0, bytesRead);
                        Console.WriteLine($"Received: {receivedMessage}");

                        // Эхо-ответ
                        var response = $"Echo: {receivedMessage}";
                        var responseData = Encoding.UTF8.GetBytes(response);
                        await stream.WriteAsync(responseData, 0, responseData.Length);

                        if (connection.State == System.Data.ConnectionState.Open)
                        {
                            connection.Close();
                        }
                    }
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine($"Client handling error: {ex.Message}");
            }
            finally
            {
                lock (connectedClients)
                {
                    connectedClients.Remove(client);
                }
                client.Dispose();
                Console.WriteLine("Client disconnected");
            }
        }

        static async Task Main(string[] args)
        {
            Program server = new Program();
            IPAddress ipAddress = IPAddress.Parse("127.0.0.1");
            int port = 2025;
            await server.StartServerAsync(ipAddress, port);
        }

    }
}
